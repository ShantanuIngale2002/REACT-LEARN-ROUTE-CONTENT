import React, { useState } from "react";
import Task1 from "./Task1";

// always use useState in function module
export default function App() {

  // traditional way to increment the count
  // var count = 0;
  // function incrementCount() {
  //   count += 1;
  //   document.getElementById("countEle").innerHTML = count;
  // }

  // useState holds current state which can be used to modify, for ex
  // const state = useState(0);
  // console.log(state); // provides the array [state, function()]
  //console.log(state[0]); // provides the value of state from array

  // way to assign variables value
  // [red, green, blue] = [256, 45 ,60];

  // using stuff we do this
  const [count, setCount] = useState(0);
  function increase() {
    setCount(count + 1);
  }
  function decrease() {
    setCount(count - 1);
  }





  return (
    <div className="container">

      {/* traditional way */}
      {/* <h1 id="countEle">0</h1>
      <button onClick={incrementCount}>+</button> */}

      {/* useState */}
      <h1>{count}</h1>
      <button onClick={decrease}>-</button>
      <button onClick={increase}>+</button>

      <div>------------------------------------</div>

      <Task1 />

    </div>
  );
}
