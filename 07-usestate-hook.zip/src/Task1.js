import { React, useState } from "react";

export default function Task1(props) {

    const [time, setTime] = useState(new Date().toLocaleTimeString());

    function getTime() {
        setTime(new Date().toLocaleTimeString());
    }
    // update state every 1 second.
    setInterval(getTime, 1000);

    return (
        <div>
            <h1>{time}</h1>
            <button>Get Time</button>
        </div>
    );
}