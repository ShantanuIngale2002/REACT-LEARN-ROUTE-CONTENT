import react from "react";

export default function Login() {
    return (
        <form className="form">
            <input type="email" placeholder="Enter your email" />
            <input type="password" placeholder="Enter your password" />
            <button type="submit">Login</button>
        </form>
    )
}