import "../public/styles.css";
import Login from "./Components/Login";
import Register from "./Components/Register";
import Form from "./Components/Form";

var loggedin = false; // use for task 1
var userisregistered = true; // use for task 2 and 3

// we can do this but ternary makes this task much simpler
// function renderAccordingly() {
//   if (loggedin) {
//     return (<h1>Hello</h1>);
//   } else {
//     return (<Login />)
//   }
// }

export default function App() {
  return (
    <div className="container">

      {/* TASK 01 - create login*/}
      {/* {renderAccordingly()} */}
      {/* {loggedin ? <h1>Hello</h1> : <Login />} */}

      {/* TASK 02 - create register and use var to surf among them */}
      {/* if user is registered then show login else do registeration */}
      {/* {userisregistered ? <Login /> : <Register />} */}

      {/* TASK 03 - create only form.js common for login and register then 
          1. show login / register into button
          2. show confirm password input only in register not for login
      */}
      <Form isregistered={userisregistered} />

      {/* JUST DEMO-ACTIVE TASK */}
      {/* {new Date().getHours()<4 ? <h1>Why are you still working?</h1> : true} */}
      {/* here we can do like this or use react && ie. "condition && expression" ie. if condition then expression*/}
      {new Date().getHours() < 4 && <h1>Why are you still working ?</h1>}
    </div>
  );
}
