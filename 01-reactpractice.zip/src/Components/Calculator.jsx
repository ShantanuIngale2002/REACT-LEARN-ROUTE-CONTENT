import React from "react";

export function add(n1,n2){return n1+n2;}
export function subtract(n1,n2){return n1-n2;}
export function multiply(n1,n2){return n1*n2;}
export function divide(n1,n2){return n1/n2;}
