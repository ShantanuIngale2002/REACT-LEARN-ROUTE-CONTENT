import React from "react";

export default function Fruitslist(){
    return(
        <o>
            <li>Apple</li>
            <li>Mango</li>
            <li>Watermelon</li>
        </o>
    );
}