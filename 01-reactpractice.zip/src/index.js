// import { StrictMode } from "react";
// import { createRoot } from "react-dom/client";

// import App from "./App";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(
//   <StrictMode>
//     <App />
//   </StrictMode>
// );

// var React = require("react");
// var ReactDOM = require("react-dom");

// // ReactDOM.render("[WHAT TO SHOW],[WHERE TO SHOW]");
// ReactDOM.render(<h1>Hello world!</h1>,document.getElementById("root"));

import React from 'react';
import ReactDOM from 'react-dom';

// >>>>Practice 1
// const lucky=2;
// const fname="shan";
// const lname='tanu';
// ReactDOM.render(
//   <div>
//     <h1>Lucky number</h1>
//     <p>Your name is {`${fname} ${lname}`}</p>
//     <p>My lucky number is {lucky}</p>
//   </div>,
//   document.getElementById('root')
// );

// >>>>>Practice 2
// const name = "Shantanu";
// const dateYear = new Date().getFullYear();

// ReactDOM.render(
//   <div>
//     <p>Created by {name}</p>
//     <p>Copyright @{dateYear}</p>
//   </div>,
//   document.getElementById('root')
// );

//>>>>>>Practice 3
// ReactDOM.render(
//   <div>
//     <h1 className="heading" contentEditable='true' spellCheck='false'>My fav fruits</h1>
//     <o>
//       <li>Apple</li>
//       <li>Orange</li>
//       <li>Watermelon</li>
//     </o>
//   </div>,
//   document.getElementById('root')
// );

//>>>>>Practice 4
// const getHour = new Date().getHours();
// let message="";
// let customText ={color:""};
// if(getHour>13 && getHour<18){
//   message="Good Afternoon";
//   customText.color="red";
// } else if (getHour > 18 && getHour < 24){
//   message="Good Evening";
//   customText.color="blue";
// }else{
//   message="Good Morning";
//   customText.color="green";
// }
// ReactDOM.render(
//   <div>
//     <h1 style={customText}>{message}</h1>
//     <p>Current time is "{getHour}" and custom text color is "{customText.color}".</p>
//   </div>,
//   document.getElementById('root')
// );

//>>>>>>>Practice 5
// import Fruitslist from "./Components/Fruitslist";
// ReactDOM.render(
//   <div>
//     <h1>My fav fruits</h1>
//     <Fruitslist/>
//   </div>,
//   document.getElementById('root')
// );

// >>>>Practice 6
// import Pi,{doublePi,triplePi} from "./Components/Pi";
// ReactDOM.render(
//   <div>
//     <h1>The values of PI's</h1>
//     <p>pi is {Pi}</p>
//     <p>pi doubled is {doublePi()}</p>
//     <p>pi tripled is {triplePi()}</p>
//   </div>,
//   document.getElementById('root')
// );


// >>> Practice 7
import * as Calc from "./Components/Calculator"
ReactDOM.render(
  <div>
    <h1>Basic calculator</h1>
    <p>Addition of 77 and 33 is {Calc.add(77,23)}</p>
    <p>Subtraction of 77 and 33 is {Calc.subtract(77,23)}</p>
    <p>Multiplication of 77 and 33 is {Calc.multiply(77,23)}</p>
    <p>Division of 77 and 33 is {Calc.divide(77,23)}</p>
  </div>,
  document.getElementById('root')
);
