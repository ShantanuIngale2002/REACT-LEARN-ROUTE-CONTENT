import "../public/styles.css";
import Slot from "./Components/Slot";
import Emojipedia from "../emojipedia";


function createSlots(ele) {
  return (
    <Slot
      key={ele.id}
      id={ele.id}
      emoji={ele.emoji}
      title={ele.name}
      desc={ele.meaning}
    />
  )
}

export default function App() {
  return (
    <div className="App">
      <h1> <span>Emojipedia</span> </h1>
      <dl className="dictionary">
        {Emojipedia.map(createSlots)}
      </dl>
    </div>
  );
}
