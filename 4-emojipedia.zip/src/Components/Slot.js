import React from "react"

export default function Slot(props) {
    return (
        <div className="term">
            <dt>
                <span className="emoji" role="img" aria-label="Tense Biceps"> {props.emoji} </span>
                <span> {props.id} : {props.title} </span>
            </dt>
            <dd>
                {props.desc}
            </dd>
        </div>
    );
}