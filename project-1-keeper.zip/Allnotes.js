const notes = [
    {
        key: 1,
        title: "Loops",
        content: "Loops, also known as iterative statements, are used when we need to execute a block of code repetitively. Loops in programming are control flow structures that enable the repeated execution of a set of instructions or code block as long as a specified condition is met. Loops are fundamental to the concept of iteration in programming, enhancing code efficiency, readability and promoting the reuse of code logic."
    },
    {
        key: 2,
        title: "Arrays",
        content: "In Computer Science, an array is a sequential collection of elements that are stored in contiguous memory locations. Each element in the array is identified by an index, and all elements have the same data type. Think of it as a row of lockers, where each locker holds a piece of data, and you can access them by their position (index). The base index is typically 0, and the position of each element is calculated using an offset from this base value. Arrays are commonly used for efficient data storage and retrieval."
    },
    {
        key: 3,
        title: "Functions",
        content: "In programming, a function is a self-contained block of code that performs a specific task or operation. It allows programmers to encapsulate functionality, making it easier to manage and reuse code. Functions can take input parameters, process them, and optionally return a result. They play a crucial role in breaking down complex programs into smaller, more manageable pieces, promoting modularity and code organization."
    },
    {
        key: 4,
        title: "If-Elseif-Else",
        content: "An if-else statement evaluates a given condition and executes different code blocks based on whether that condition is true or false. It provides a way to control the flow of your program, allowing you to choose between alternative paths based on specific criteria."
    },
];

export default notes;