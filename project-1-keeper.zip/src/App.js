import "../public/styles.css";

import Header from "./components/Header"
import Footer from "./components/Footer"

import Createarea from "./components/createArea";

export default function App() {
  return (
    <div className="App">
      <Header />

      {/* to add cards from user cards */}
      <Createarea />

      {/* below is code for creating the keeper cards from data allNotes.js */}
      {/* <Addcards allNotes={allNotes} /> */}

      <Footer />
    </div>
  );
}
