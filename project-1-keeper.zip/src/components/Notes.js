import React from "react";

export default function Notes(props) {

    // since prop.del() gets called direcly w/o even click
    // to prevent it make inside another function that triggered on click
    function deleteNoteCard(event) {
        // prevents page refresh
        event.preventDefault();
        // passing id to filter out the note ie. delete note
        props.deleteNote(props.id);
    }

    // returns this body
    return (
        <div className="note">
            <h1>{props.title}</h1>
            <p>{props.content}</p>
            <button
                onClick={deleteNoteCard}
            >Delete</button>
        </div>
    );
};