import { React, useState } from "react";
import Addcards from "./AddCards";

function CreateArea() {

    // states initiations
    const [count, setCount] = useState(1);
    const [title, setTitle] = useState("");
    const [desc, setDesc] = useState("");
    const [cards, setCards] = useState([]);

    // after change in inputs
    function handleChange(event) {
        // according to name update value
        const { name, value } = event.target;
        if (name === "title") {
            setTitle(value);
        } else if (name === "content") {
            setDesc(value);
        }
    };

    // after submit is cliked
    function handleSubmit(event) {
        // refresh prevent
        event.preventDefault();
        // no need of same title note
        let cardsContain = false;
        cardsContain = cards.some((item) => {
            if (item.title === title) { return true; }
        });
        // update state inc. new note
        if (title.length > 0 && !cardsContain) {
            setCards(prevValue => {
                return [...prevValue, { id: count, title: title, content: desc }];
            })
            // update states
            setTitle("");
            setDesc("");
            setCount(count + 1);
        }
    }

    // delete note "passed as prop"
    function deleteNote(index) {
        setCards(prevValue => {
            return prevValue.filter((item) => {
                return (item.id != index);
            })
        });
    }

    // returns this body
    return (
        <div>
            <form>
                <input name="title" placeholder="Title" value={title}
                    onChange={handleChange} />
                <textarea name="content" placeholder="Take a note..." value={desc} rows="3"
                    onChange={handleChange} />
                <button onClick={handleSubmit}>Add</button>
            </form>

            {/* passing cards and function to delete note */}
            <Addcards allNotes={cards} deleteNote={deleteNote} />

        </div>
    );
}

export default CreateArea;
