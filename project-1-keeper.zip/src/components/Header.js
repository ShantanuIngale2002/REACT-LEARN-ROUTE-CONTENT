import React from "react";
import ReactDOM from "react-dom";

export default function Header(){
    return (
        <header>
            <h1>KEEPER</h1>
        </header>
    )
}