import "../public/styles.css";

export default function App() {

  // task 1 // declarative
  var isDone = true;
  const strikeThrough = { textDecoration: "line-through" };

  // task 2 // imperative
  function strike() {
    document.getElementById("paratask2").style.textDecoration = "line-through";
  }
  function unstrike() {
    document.getElementById("paratask2").style.textDecoration = null;
  }

  // task 3 - these tells us that when we change value of variable
  //          it is not neccessary that rendered elements will change accordingly
  //          re-render may do but at real time not possible
  //          Hence we require stuff called "HOOKS" in react.
  // hook function allows us to hook into state of element hence read/modify it

  var tobeDone = true;
  const strikeIt = { textDecoration: "line-through" };
  function strikeNeed() {
    tobeDone = true;
  }
  function unstrikeNeed() {
    tobeDone = false;
  }




  return (
    <>
      {/* task 1 */}
      <p style={isDone && strikeThrough}>Paragraph 1</p>
      <p style={!isDone ? strikeThrough : null}>Paragraph 2</p>

      <div>---------------------------------</div>

      {/* task 2 */}
      <p id="paratask2" onClick={strike}>This will change</p>
      <button onClick={strike}> Stike it </button>
      <div></div>
      <button onClick={unstrike}> unStike it </button>

      <div>---------------------------------</div>

      {/* task 3 */}
      <p style={tobeDone ? strikeIt : null}>Need to change</p>
      <button onClick={strikeNeed}> try stike </button>
      <div></div>
      <button onClick={unstrikeNeed}> try unStike </button>
    </>
  );
}
