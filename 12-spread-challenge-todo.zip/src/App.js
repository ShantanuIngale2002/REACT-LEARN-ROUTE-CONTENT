import { React, useState } from "react";
import "../public/styles.css";
import Form from "./components/Form";

export default function App() {
  return (
    <div className="container">
      <div className="heading">
            <h1>To-Do List</h1>
      </div>

      {/* here form is only required because we get list into form */}
      <Form />

    </div>
  );
}
