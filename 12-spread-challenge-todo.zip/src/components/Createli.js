import { React, useState } from "react";

export default function Creatli(props) {

    // LOGIN TO ONLY STRIKE THROGUH TODOITEM
    // const [lineIt, setLineIt] = useState(false);
    // function lineItOver() {
    //     if (lineIt) { setLineIt(false); }
    //     else { setLineIt(true); }
    // }

    // LOGIC TO ACTUALLY DELTETE IT

    return (
        // LOGIN TO ONLY STRIKE THROGUH TODOITEM
        // <li style={{ textDecoration: lineIt ? "line-through" : "none" }}
        //     onClick={lineItOver}
        // >{props.tditem}</li>

        // LOGIC TO DELETE IT ACTUALLY FROM ARRAY
        <li onClick={() => {
                props.onChecked(props.id);
            }
        // onClick={props.onChecked} may direcly execute function which we not need
        // only get triggered when actually is clicked
        }> {props.tditem} </li>
    );
}