import { React, useState } from "react";
import Creatli from "./Createli";

export default function List(props) {

    return (
        <div>
            <ul>
                {props.items.map((todoitem, index) => (
                    // to delete we need id hence need unique key that we get from index parameter
                    <Creatli key={index}
                        id={index}
                        tditem={todoitem}
                        onChecked={props.onChecked}
                    />
                    //  in real world react doesnt allow using index like this
                    // instead unique indentification key that we may acquire using package uuid
                ))}
            </ul>
        </div>
    );
}