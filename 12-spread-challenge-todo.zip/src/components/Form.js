import { React, useState } from "react";
import List from "./List";

export default function Form() {
    // data store states
    const [itemText, setItemText] = useState("");
    const [items, setItems] = useState([]);
    // handle change in i/p to update state
    function handleChange(event) {
        let value = event.target.value;
        setItemText(value);
    };
    // add item in items state i.e update it check if not null and not duplicate
    function addItem() {
        let flag = items.some((item) => {
            if (item === itemText) { return true; }
        });
        if (itemText.length > 0 && !flag) {
            setItems([...items, itemText]);
            setItemText("");
        }
    };
    // it is passed with props in order to get id from List component to filter out clicked to be deleted id item
    function deleteItem(id) {
        setItems(prevItems => {
            return prevItems.filter((item, index) => {
                return index !== id;
            });
        });
    };

    return (
        <>
            <div className="form">
                <input type="text" name="itemName"
                    onChange={handleChange}
                    value={itemText}
                />
                <button
                    onClick={addItem}
                ><span>Add</span></button>
            </div>
            {/* list item is given with state and delete function as well */}
            <List items={items} onChecked={deleteItem} />
        </>
    );
}