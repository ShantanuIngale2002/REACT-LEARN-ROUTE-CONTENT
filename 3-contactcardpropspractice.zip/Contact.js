const contacts = [
    {
        id: 1,
        name: "Vin Diesel",
        imgURL: "https://th.bing.com/th?id=ODL.4928fd815d5065c07d01bd54e6e1b7ee&w=188&h=148&c=10&rs=1&qlt=99&o=6&dpr=1.3&pid=13.1",
        phone: "+123 456 789",
        email: "vin@bhau"
    },
    {
        id: 2,
        name: "Justin Bieber",
        imgURL: "https://i.pinimg.com/originals/b6/a8/04/b6a8044fbfb8065f519734a69ae77463.jpg",
        phone: "+987 654 321",
        email: "justin@beta"
    },
    {
        id: 3,
        name: "Amitabh Bachchan",
        imgURL: "https://th.bing.com/th/id/OIP.QUcEQpx4ASuvC0CU18PMqwHaE8?w=280&h=187&c=7&r=0&o=5&dpr=1.3&pid=1.7",
        phone: "+91 98765 43210",
        email: "amitabh@bacchan"
    }
];
export default contacts;