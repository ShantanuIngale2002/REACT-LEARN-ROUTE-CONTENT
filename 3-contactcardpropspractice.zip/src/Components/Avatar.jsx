import react from "react";

export default function Avatar(props){
    return (<img className="circle-img" src={props.img}></img>)
}