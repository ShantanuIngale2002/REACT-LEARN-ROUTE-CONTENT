import React from "react";
import Avatar from "./Avatar";

export default function Card(props) {
    return (
        <div className="card">
            <div className="top">
                <p className="info" style={{ marginLeft: '1rem' }}>ID : {props.id}</p>
                <h2 className="name">{props.name}</h2>
                <Avatar img={props.img} />
            </div>
            <div className="bottom">
                <p className="info">{props.tel}</p>
                <p className="info">{props.email}</p>
            </div>
        </div >
    );
};