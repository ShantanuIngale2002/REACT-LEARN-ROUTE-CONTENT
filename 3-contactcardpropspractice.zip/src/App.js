import React from "react";
import Card from "./Components/Card";
import contacts from "../Contact";

// function with map just maps values of each object correspondingly.
function createCard(contact) {
  return (
    <Card
      key={contact.id} // to solve unique key required error in console althought value is not neccesarily required anyway.
      // HERE the key is not accessible hence if we require id then pass separetly like below
      id={contact.id}
      name={contact.name}
      img={contact.imgURL}
      tel={contact.phone}
      email={contact.email}
    />
  );
}

export default function App() {
  return (
    <div className="App">
      <h1 className="heading">DONT KNOW EXACTLY WHY BUT THESE PEOPLE ARE HERE ANYWAY</h1>
      {contacts.map(createCard)}
    </div>
  );
}
