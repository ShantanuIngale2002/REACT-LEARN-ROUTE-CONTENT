import { React, useState } from "react";
import "../public/styles.css";
import TaskTODO from "./components/Tasktodo";

export default function App() {

  // Learning
  const [heading, setHeading] = useState("Hello");

  // below functionalities are to handle event for submit button
  const [bgColor, setBgColor] = useState(false);
  function handleClick() { setHeading("Never"); }
  function mouseHoverIn() { setBgColor(true); }
  function mouseHoverOut() { setBgColor(false); }

  // below functionalities are to handle change event for input
  const [name, setName] = useState("");
  function handleInputChange(event) { setName(event.target.value); }


  return (
    <div className="container">
      {/* learning */}
      <h1>{heading}</h1>

      <h2 style={{ margin: "1rem" }}>{name}</h2>
      <input type="text" placeholder="Try entering your name ?"
        onChange={handleInputChange} />

      <button style={{ backgroundColor: bgColor ? "black" : "white" }}
        onClick={handleClick}
        onMouseOver={mouseHoverIn}
        onMouseOut={mouseHoverOut} > Submit </button>

      <div style={{ margin: "2rem" }}>------------------------------</div>
      {/* performing task  */}
      <TaskTODO />

    </div>
  );
}
