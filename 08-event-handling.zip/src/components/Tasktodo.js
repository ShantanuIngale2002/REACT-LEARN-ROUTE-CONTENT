import { React, useState } from "react";

export default function Tasktodo() {

    const [hover, setHover] = useState(false);
    const [person, setPerson] = useState("");
    const [headingName, setHeadingName] = useState("");

    function hoverIn() { setHover(true); }
    function hoverOut() { setHover(false); }
    function initInput(event) { event.target.value = ""; }
    function handleInputChange(event) { setPerson(event.target.value); }
    function handleFormSubmit(event) {
        setHeadingName(person);
        event.preventDefault(); // these method prevents default behaviour ie. here form submit refresh the page
    }



    return (
        <>
            <h1>Name {headingName}</h1>
            <form onSubmit={handleFormSubmit}>
                <input type="text" placeholder="Try your name"
                    onChange={handleInputChange}
                />
                <button
                    style={{ backgroundColor: hover ? "black" : "white" }}
                    onMouseOver={hoverIn}
                    onMouseOut={hoverOut}
                    onClick={initInput}
                >Submit</button>
            </form>
        </>
    );
}