// SPREAD OPERATOR (...) TO LIKE CONCATENATE STUFF 

// Array
const citrus = ["Lime", "Lemon", "Orange"];
const fruits1 = ["Apple", "Mango", "Banana", ...citrus];
// op : ["Apple", "Mango", "Banana", "Lime", "Lemon", "Orange"]
const fruits2 = ["Apple", ...citrus, "Mango", "Banana"];
// op : ["Apple", "Lime", "Lemon", "Orange", "Mango", "Banana"]

// objects
const userInfo = {
    fName: "userFname", lName: "userLname"
};

const usersDummy = {
    id: 1,
    userInfo,
    userName: "user@01"
};
// here in usersDymmy userInfo will be added as diff obj 
// like {id:val, 
// userInfo:{
//     fName:"val", lName:"val"
// }, 
// userName:"val"};
// WHICH WE DO NOT NECCESSARILY ALWAYS NEED HENCE USE SPREAD OPERATOR

const users = {
    id: 1,
    ...userInfo,
    userName: "user@01"
};
// op - {id, fName, lName, userName} as single obj w/ vlaues ofc.