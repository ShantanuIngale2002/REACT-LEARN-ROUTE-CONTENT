import { React, useState } from "react";

// CHALLENGE BELONGS TO PREV LEARN CARD - MANAGE-STATES TO LEARN NEED TO SPREAD OPERATOR
export default function Challenge() {

    // useState initialized
    const [contact, setContact] = useState({
        fName: "",
        lName: "",
        eMail: ""
    });

    function handleChange(event) {
        const { name, value } = event.target;
        setContact((prevValue) => {
            if (name === "fName") {
                return ({
                    fName: value, lName: prevValue.lName, eMail: prevValue.eMail
                })
            } else if (name === "lName") {
                return ({
                    fName: prevValue.fName, lName: value, eMail: prevValue.eMail
                })
            } else if (name === "eMail") {
                return ({
                    fName: prevValue.fName, lName: prevValue.lName, eMail: value
                })
            }
        });
    }

    return (
        <div>
            <h1>Hello {contact.fName} {contact.lName}</h1>
            <p>{contact.eMail}</p>
            <form>
                <input type="text" name="fName" placeholder="First name"
                    onChange={handleChange} />
                <input type="text" name="lName" placeholder="Last name"
                    onChange={handleChange} />
                <input type="eMail" name="eMail" placeholder="Enter Email"
                    onChange={handleChange} />
                <button>Submit</button>
            </form>
        </div>
    );
}