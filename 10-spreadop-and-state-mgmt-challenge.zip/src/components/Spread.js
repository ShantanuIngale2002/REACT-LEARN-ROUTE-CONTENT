import { React, useState } from "react";


export default function Spread() {

    // useState initialized
    const [contact, setContact] = useState({
        fName: "",
        lName: "",
        eMail: ""
    });

    // using spread (...) we make it more simple and less lines of code
    function handleChange(event) {
        const { name, value } = event.target;
        setContact((prevValue) => {
            return {
                ...prevValue,
                [name]: value
            }
        });
    }
    // here "name" if written directly it can be interpreted as string
    // Hence use "[name]" to make it interpret as key for object



    return (
        <div>
            <h1>Hello {contact.fName} {contact.lName}</h1>
            <p>{contact.eMail}</p>
            <form>
                <input type="text" name="fName" placeholder="First name"
                    onChange={handleChange} />
                <input type="text" name="lName" placeholder="Last name"
                    onChange={handleChange} />
                <input type="eMail" name="eMail" placeholder="Enter Email"
                    onChange={handleChange} />
                <button>Submit</button>
            </form>
        </div>
    );
}