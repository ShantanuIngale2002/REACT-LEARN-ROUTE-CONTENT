import { React, useState } from "react";
import "../public/styles.css";
import Challenge from "./components/Challenge";
import Spread from "./components/Spread";

export default function App() {
  return (
    <div className="container">

      <Challenge />

      {/* In challenge the logic for input changes is workload */}
      {/* So to reduce such work load we have "SPREAD" operator */}
      <h4 style={{ margin: "2rem" }}>-----------------------</h4>

      <Spread />

    </div>
  )
}
