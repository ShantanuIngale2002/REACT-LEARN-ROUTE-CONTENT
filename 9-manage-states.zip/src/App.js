import { React, useState } from "react";
import "../public/styles.css";
import Learn1 from "./components/Learn1";

export default function App() {
  return (
    <div className="container">
      <Learn1 />
    </div>
  );
}
