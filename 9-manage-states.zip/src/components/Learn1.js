import { React, useState } from "react";

// task is to : change Hello + "fname and lname" independently


// Upto current learning, we do this but we noticed here that its painful
// to have multiple states and functions so lets just be creating below

// export default function Learn1() {
//     const [headFname, setHeadFname] = useState("");
//     const [headLname, setHeadLname] = useState("");
//     function changeFname(event) { setHeadFname(event.target.value); }
//     function changeLname(event) { setHeadLname(event.target.value); }

//     return (
//         <>
//             <h1>Hello {headFname} {headLname}</h1>
//             <form>
//                 <input type="text" name="fName" placeholder="First Name"
//                     onChange={changeFname} />
//                 <input type="text" name="LName" placeholder="Last Name"
//                     onChange={changeLname} />
//                 <button>Submit</button>
//             </form>
//         </>
//     );
// }


// lets be creative and efficient here

export default function Learn1() {
    // just create object
    const [fullName, setFullName] = useState({
        fName: "",
        lName: ""
    });
    // common handle, handled using input name to set value to keys
    function handleChange(event) {
        // let ipName = event.target.name;
        // let newValue = event.target.value;
        // if (ipName === "fName") {
        //     setFullName({
        //         fName: newValue,
        //         lName: fullName.lName
        //     })
        // } else if (ipName === "lName") {
        //     setFullName({
        //         fName: fullName.fName,
        //         lName: newValue
        //     })
        // }

        // VIMP#NOTE >> DONT USE "event.target.name/value/anything" DIRECLT INTO "setFullName" ie. change state, IT MAY GIVE "SYNTHETIC STATE USE" ERROR IN BIG FUTURE APPLICATOINS

        // lets be more creative here as well
        // instead using setFullName twice we can do this
        // getting input information through obj destructuring since these keys and values are passed as objs also new keys must similar to attributes keys for obj destructuring
        const { name, value } = event.target;
        // setting full name using arrow function over using prev values and returning the objets using logic
        setFullName((prevValue) => {
            if (name === "fName") {
                return { fName: value, lName: prevValue.lName };
            } else if (name === "lName") {
                return { fName: prevValue.fName, lName: value };
            }
        });
    }

    return (
        <>
            <h1>Hello {fullName.fName} {fullName.lName}</h1>
            <form>
                <input type="text" name="fName" placeholder="First Name"
                    onChange={handleChange} />
                <input type="text" name="lName" placeholder="Last Name"
                    onChange={handleChange} />
                <button>Submit</button>
            </form>
        </>
    );
}