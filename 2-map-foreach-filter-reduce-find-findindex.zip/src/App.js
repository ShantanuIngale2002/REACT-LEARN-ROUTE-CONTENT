import "../public/styles.css";


const nums = [2, 4, 20, 100]
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> MAPPING / FOR-EACH
// >>>>>>> DESC : used to map items in array or objects whereever required.
// way 1.1 - forEach
// var newNumbers=[]
// function double(x){
//   newNumbers.push(x*2);
// }
// nums.forEach(double);
// console.log(newNumbers);

// way 1.2 - map
// var newNumbers=[]
// function double(x){
//   newNumbers.push(x*2);
// }
// nums.map(double);
// console.log(newNumbers);

// way 2.1 - forEach
// var newNumbers = []
// nums.forEach((x) =>{ newNumbers.push(x*2); });
// console.log(newNumbers);

// way 2.2 - map (best out of 1.1/1.2/2.1/2.2)
// var newNumbers = nums.map((x) => { return x * 2; });
// console.log(newNumbers);


const nums2 = [3, 56, 2, 48, 5]
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> FILTER
// >>>>>>> DESC : create new array by keeping values that return true.
// var newNumbers2 = [] // forEach method
// nums2.forEach((n) => {
//   if (n < 10) { newNumbers2.push(n); }
// });
// console.log(newNumbers2); // working but huge, hence filter a better option

// Fitler method instead
// var newNumbers2 = nums2.filter((n)=>{ return n<10 })
// console.log(newNumbers2);


const nums3 = [5, 10, 15, 20]
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> REDUCE
// >>>>>>> DESC : Accumulate a value by doing something to each item in array
// var newNumbers3 = 0 // forEach method
// nums3.forEach((n) => {
//   newNumbers3 += n;
// });
// console.log(newNumbers3); // working but huge, hence reduce a better option

// Reduce method instead
// var newNumbers3 = nums3.reduce((accumulator, currentNumber) => {
//   return accumulator + currentNumber;
// });
// console.log(newNumbers3);


const nums4 = [44, 6, 2, 78, 4]
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> FIND and FIND-INDEX
// >>>>>>> DESC : find : Finds 1st item if/that matches from an array || findIndex - returns its index else undefined
// var newNumbers4pt1 = nums4.find((n) => { return n < 20; });
// var newNumbers4pt2 = nums4.findIndex((n) => { return n < 20; });
// console.log(newNumbers4pt1 + " " + newNumbers4pt2); // return only 1st match then get break-off else undefined


export default function App() {
  return (
    <div className="App">
    </div>
  );
}
