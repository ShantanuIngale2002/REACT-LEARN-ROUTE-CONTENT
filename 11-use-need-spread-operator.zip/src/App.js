// FUNTION FROM PREV CHALLENGE TO HANDLE CHANGE OF INPUTS
// function handleChange(event) {
//   const { name, value } = event.target;
//   setContact((prevValue) => {
//     if (name === "fName") {
//       return ({
//         fName: value, lName: prevValue.lName, eMail: prevValue.eMail
//       })
//     } else if (name === "lName") {
//       return ({
//         fName: prevValue.fName, lName: value, eMail: prevValue.eMail
//       })
//     } else if (name === "eMail") {
//       return ({
//         fName: prevValue.fName, lName: prevValue.lName, eMail: value
//       })
//     }
//   });
// ISNT THERE WAY TO REDUCE SUCH WORK LOAD.? YES ITS SPREAD OPERATOR


import { React, useState } from "react";
import "../public/styles.css";

export default function App() {
  return (
    <div className="container">
    </div>
  );
}
